﻿namespace _05BarracksFactory.Contracts
{
    public interface IDestroyable
    {
        int Health { get; set; }
    }
}
