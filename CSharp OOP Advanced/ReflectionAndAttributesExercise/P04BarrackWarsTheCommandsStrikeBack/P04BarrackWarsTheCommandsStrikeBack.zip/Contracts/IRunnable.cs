﻿namespace _05BarracksFactory.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
