﻿namespace _05BarracksFactory.Contracts
{
    public interface IExecutable
    {
        string Execute();
    }
}
