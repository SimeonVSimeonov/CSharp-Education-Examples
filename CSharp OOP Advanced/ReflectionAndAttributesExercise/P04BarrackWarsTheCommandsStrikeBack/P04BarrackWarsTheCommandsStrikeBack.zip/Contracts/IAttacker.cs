﻿namespace _05BarracksFactory.Contracts
{
    public interface IAttacker
    {
        int AttackDamage { get; }
    }
}
